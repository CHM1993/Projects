#ifndef ORACLE_IMPL_H_
#define ORACLE_IMPL_H_

#ifdef __cplusplus
extern "C" {
#endif

const char **oracle(const char *word);

void initSeed(int seed);


#ifdef __cplusplus
}
#endif

#endif
